import { useCallback, useEffect, useState } from 'react'
import { supabase } from '../lib'
import { useAuth } from '../auth'
import { Avatar, when } from '../components'

type Room = { id: string; host: string; host_name: string | null; title: string; kind: string; code: string; created_at: string }

export default function Reunions() {
  const { userId, profile } = useAuth()
  const [rooms, setRooms] = useState<Room[]>([])
  const [base, setBase] = useState('https://meet.jit.si')
  const [title, setTitle] = useState('')
  const [kind, setKind] = useState('reunion')
  const [err, setErr] = useState('')

  const load = useCallback(async () => {
    const since = new Date(Date.now() - 12 * 3600 * 1000).toISOString()
    const r = await supabase.from('rooms').select('*').is('ended_at', null).gte('created_at', since)
      .order('created_at', { ascending: false })
    if (r.error) setErr(r.error.message)
    else setRooms((r.data ?? []) as Room[])
    const st = await supabase.from('app_settings').select('value').eq('key', 'jitsi_url').maybeSingle()
    if (st.data && st.data.value) setBase((st.data.value as string).replace(/\/+$/, ''))
  }, [])

  useEffect(() => { load() }, [load])

  async function create() {
    setErr('')
    const r = await supabase.from('rooms').insert({ title: title.trim(), kind })
    if (r.error) { setErr(r.error.message); return }
    setTitle('')
    load()
  }

  async function end(id: string) {
    await supabase.from('rooms').update({ ended_at: new Date().toISOString() }).eq('id', id)
    load()
  }

  const lives = rooms.filter(r => r.kind === 'live')
  const meets = rooms.filter(r => r.kind !== 'live')

  function RoomCard({ r }: { r: Room }) {
    const url = base + '/' + r.code
    return (
      <div className="card">
        <div className="row">
          <div className="row" style={{ justifyContent: 'flex-start' }}>
            <Avatar name={r.host_name} size={34} />
            <div>
              <strong>{r.title}</strong>
              <div className="muted">{r.host_name || 'Membre'} · {when(r.created_at)}</div>
            </div>
          </div>
          <span className="badge">{r.kind === 'live' ? 'Live' : 'Réunion'}</span>
        </div>
        <div className="row" style={{ marginTop: 10 }}>
          <a href={url} target="_blank" rel="noopener noreferrer"><button className="small">Rejoindre</button></a>
          {(r.host === userId || (profile && profile.role === 'admin')) && (
            <button className="small ghost" onClick={() => end(r.id)}>Terminer</button>
          )}
        </div>
      </div>
    )
  }

  return (
    <>
      <h2>Réunions et lives</h2>
      <div className="card form" style={{ marginBottom: 16 }}>
        <strong>Démarrer une salle</strong>
        <input placeholder="Titre (ex. Cours d'informatique 6ème)" value={title} onChange={e => setTitle(e.target.value)} />
        <select value={kind} onChange={e => setKind(e.target.value)}>
          <option value="reunion">Réunion (gratuit)</option>
          <option value="live">Live (réservé aux abonnés Premium)</option>
        </select>
        <button onClick={create} disabled={!title.trim()}>Créer la salle</button>
        <p className="muted" style={{ margin: 0 }}>
          La salle s'ouvre dans Jitsi Meet. La personne qui démarre la salle doit se connecter une fois avec un compte Google, GitHub ou Facebook. Les participants rejoignent sans compte.
        </p>
      </div>
      {err && <p className="msg">{err}</p>}

      <h3>En direct</h3>
      {lives.length === 0 && <p className="muted">Aucun live en cours.</p>}
      <div className="list">{lives.map(r => <RoomCard key={r.id} r={r} />)}</div>

      <h3>Réunions ouvertes</h3>
      {meets.length === 0 && <p className="muted">Aucune réunion ouverte.</p>}
      <div className="list">{meets.map(r => <RoomCard key={r.id} r={r} />)}</div>
    </>
  )
}
