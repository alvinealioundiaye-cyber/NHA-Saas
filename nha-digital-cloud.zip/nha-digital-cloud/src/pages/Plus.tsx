import { Link } from 'react-router-dom'
import { useAuth } from '../auth'
import { Avatar } from '../components'

export default function Plus() {
  const { profile, signOut } = useAuth()
  const name = (profile && (profile.full_name || profile.email)) || 'Membre'
  return (
    <>
      <div className="card row" style={{ justifyContent: 'flex-start', marginBottom: 16 }}>
        <Avatar name={name} size={48} />
        <div>
          <strong>{name}</strong>
          <div className="muted">{profile ? profile.role : ''}</div>
        </div>
      </div>
      <div className="menu">
        <Link to="/reunions">Réunions et lives <span>›</span></Link>
        <Link to="/academie">Académie <span>›</span></Link>
        <Link to="/abonnement">Abonnement Premium <span className="badge">Premium</span></Link>
        <Link to="/ia">Assistant IA <span>›</span></Link>
        {profile && profile.role === 'admin' && <Link to="/utilisateurs">Utilisateurs <span>›</span></Link>}
        <button className="item" onClick={signOut}>Se déconnecter</button>
      </div>
    </>
  )
}
