import { useCallback, useEffect, useState } from 'react'
import { supabase } from '../lib'
import { useAuth } from '../auth'

type Req = { id: string; user_name: string | null; operateur: string; reference: string; montant: number | null; status: string; created_at: string }

const when = (d: string) => new Date(d).toLocaleString('fr-FR', { dateStyle: 'short', timeStyle: 'short' })
const label: Record<string, string> = { en_attente: 'En attente', approuve: 'Approuvée', refuse: 'Refusée' }

export default function Abonnement() {
  const { userId, profile } = useAuth()
  const isAdmin = profile !== null && profile.role === 'admin'
  const [plan, setPlan] = useState('gratuit')
  const [expires, setExpires] = useState<string | null>(null)
  const [prix, setPrix] = useState('1000')
  const [numero, setNumero] = useState('')
  const [reqs, setReqs] = useState<Req[]>([])
  const [operateur, setOperateur] = useState('Orange Money')
  const [reference, setReference] = useState('')
  const [msg, setMsg] = useState('')
  const [err, setErr] = useState('')

  const load = useCallback(async () => {
    if (!userId) return
    const me = await supabase.from('profiles').select('plan, plan_expires_at').eq('id', userId).single()
    if (me.data) {
      setPlan(me.data.plan as string)
      setExpires((me.data.plan_expires_at as string | null) ?? null)
    }
    const st = await supabase.from('app_settings').select('key, value')
    for (const row of (st.data ?? []) as { key: string; value: string }[]) {
      if (row.key === 'prix_fcfa') setPrix(row.value)
      if (row.key === 'numero_paiement') setNumero(row.value)
    }
    const rq = await supabase.from('subscription_requests').select('*').order('created_at', { ascending: false }).limit(50)
    if (rq.error) setErr(rq.error.message)
    else setReqs((rq.data ?? []) as Req[])
  }, [userId])

  useEffect(() => { load() }, [load])

  const premium = plan === 'premium' && expires !== null && new Date(expires) > new Date()

  async function demander() {
    setErr(''); setMsg('')
    const r = await supabase.from('subscription_requests').insert({
      operateur, reference: reference.trim(), montant: Number(prix),
    })
    if (r.error) { setErr(r.error.message); return }
    setReference('')
    setMsg('Demande envoyée. L\'administrateur l\'activera après vérification du paiement.')
    load()
  }

  async function approuver(id: string) {
    const r = await supabase.rpc('approve_subscription', { req: id, days: 30 })
    if (r.error) setErr(r.error.message)
    load()
  }

  async function refuser(id: string) {
    const r = await supabase.rpc('reject_subscription', { req: id })
    if (r.error) setErr(r.error.message)
    load()
  }

  async function enregistrerReglages() {
    setErr(''); setMsg('')
    const a = await supabase.from('app_settings').upsert({ key: 'prix_fcfa', value: prix })
    const b = await supabase.from('app_settings').upsert({ key: 'numero_paiement', value: numero })
    if (a.error || b.error) setErr((a.error ?? b.error)!.message)
    else setMsg('Réglages enregistrés.')
  }

  return (
    <>
      <h2>Abonnement</h2>
      {err && <p className="msg">{err}</p>}
      {msg && <p className="muted">{msg}</p>}

      <div className="card" style={{ marginBottom: 16 }}>
        <strong>{premium ? 'Plan Premium' : 'Plan gratuit'}</strong>
        <p className="muted">
          {premium && expires
            ? 'Publications illimitées jusqu\'au ' + new Date(expires).toLocaleDateString('fr-FR') + '.'
            : 'Accès à tout, limité à 3 publications par jour.'}
        </p>
      </div>

      {!premium && (
        <div className="card form" style={{ marginBottom: 16 }}>
          <strong>Passer à Premium : {Number(prix).toLocaleString('fr-FR')} FCFA par mois</strong>
          <p className="muted" style={{ margin: 0 }}>
            1. Envoyez {Number(prix).toLocaleString('fr-FR')} FCFA par Orange Money ou Moov Africa au {numero || '(numéro non renseigné)'}.<br />
            2. Entrez ci-dessous la référence de la transaction reçue par SMS.
          </p>
          <select value={operateur} onChange={e => setOperateur(e.target.value)}>
            <option>Orange Money</option>
            <option>Moov Africa</option>
          </select>
          <input placeholder="Référence de la transaction" value={reference} onChange={e => setReference(e.target.value)} />
          <button onClick={demander} disabled={!reference.trim()}>Envoyer la demande</button>
        </div>
      )}

      {isAdmin && (
        <div className="card form" style={{ marginBottom: 16 }}>
          <strong>Réglages (administrateur)</strong>
          <input placeholder="Prix mensuel en FCFA" type="number" value={prix} onChange={e => setPrix(e.target.value)} />
          <input placeholder="Numéro de paiement Orange / Moov" value={numero} onChange={e => setNumero(e.target.value)} />
          <button onClick={enregistrerReglages}>Enregistrer</button>
        </div>
      )}

      <h3>{isAdmin ? 'Demandes d\'abonnement' : 'Mes demandes'}</h3>
      {reqs.length === 0 && <p className="muted">Aucune demande pour le moment.</p>}
      <div className="list">
        {reqs.map(r => (
          <div className="card" key={r.id}>
            <div className="row">
              <strong>{r.user_name || 'Membre'}</strong>
              <span>{label[r.status] ?? r.status}</span>
            </div>
            <p className="muted">{r.operateur} · réf. {r.reference} · {when(r.created_at)}</p>
            {isAdmin && r.status === 'en_attente' && (
              <div className="row">
                <button onClick={() => approuver(r.id)}>Activer 30 jours</button>
                <button className="ghost" onClick={() => refuser(r.id)}>Refuser</button>
              </div>
            )}
          </div>
        ))}
      </div>
    </>
  )
}
