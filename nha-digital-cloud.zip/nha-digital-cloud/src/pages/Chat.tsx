import { useCallback, useEffect, useRef, useState } from 'react'
import { useNavigate, useParams } from 'react-router-dom'
import { supabase } from '../lib'
import { useAuth } from '../auth'
import { Avatar, when } from '../components'
import { uploadMedia } from '../social'

type Msg = { id: string; sender: string; sender_name: string | null; body: string | null; media_url: string | null; media_type: string | null; created_at: string }
type Conv = { conv_id: string; conv_is_group: boolean; conv_title: string }

export default function Chat() {
  const { id } = useParams()
  const { userId } = useAuth()
  const nav = useNavigate()
  const [msgs, setMsgs] = useState<Msg[]>([])
  const [title, setTitle] = useState('Discussion')
  const [isGroup, setIsGroup] = useState(false)
  const [text, setText] = useState('')
  const [busy, setBusy] = useState(false)
  const [err, setErr] = useState('')
  const endRef = useRef<HTMLDivElement>(null)

  const load = useCallback(async () => {
    if (!id) return
    const r = await supabase.from('messages').select('*').eq('conversation_id', id)
      .order('created_at', { ascending: true }).limit(300)
    if (r.error) setErr(r.error.message)
    else setMsgs((r.data ?? []) as Msg[])
  }, [id])

  useEffect(() => {
    if (!id) return
    load()
    supabase.rpc('my_conversations').then(r => {
      const c = ((r.data ?? []) as Conv[]).find(x => x.conv_id === id)
      if (c) { setTitle(c.conv_title); setIsGroup(c.conv_is_group) }
    })
    const timer = setInterval(load, 6000)
    const ch = supabase.channel('chat-' + id)
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'messages', filter: 'conversation_id=eq.' + id }, () => { load() })
      .subscribe()
    return () => { clearInterval(timer); supabase.removeChannel(ch) }
  }, [id, load])

  useEffect(() => { endRef.current?.scrollIntoView({ block: 'end' }) }, [msgs.length])

  async function send() {
    if (!id || !text.trim()) return
    const body = text.trim()
    setText('')
    const r = await supabase.from('messages').insert({ conversation_id: id, body })
    if (r.error) { setErr(r.error.message); setText(body) }
    load()
  }

  async function attach(file: File | null) {
    if (!id || !userId || !file) return
    setBusy(true)
    const up = await uploadMedia(file, userId)
    if (up.error) setErr(up.error)
    else {
      const r = await supabase.from('messages').insert({ conversation_id: id, media_url: up.url, media_type: up.type })
      if (r.error) setErr(r.error.message)
    }
    setBusy(false)
    load()
  }

  return (
    <div className="screen" style={{ background: '#fff' }}>
      <div className="chat-head">
        <button className="small ghost" onClick={() => nav('/messages')}>Retour</button>
        <Avatar name={title} size={34} />
        <strong>{title}</strong>
      </div>
      <div className="chat-body">
        {err && <p className="msg">{err}</p>}
        {msgs.map(m => {
          const mine = m.sender === userId
          return (
            <div key={m.id} className={mine ? 'bubble me' : 'bubble'}>
              {isGroup && !mine && <span className="who">{m.sender_name || 'Membre'}</span>}
              {m.media_url && m.media_type === 'image' && <img src={m.media_url} alt="" loading="lazy" />}
              {m.media_url && m.media_type === 'video' && <video src={m.media_url} controls playsInline preload="metadata" />}
              {m.body}
              <small>{when(m.created_at)}</small>
            </div>
          )
        })}
        <div ref={endRef} />
      </div>
      <div className="chat-send">
        <label className="attach">
          {busy ? '…' : '+'}
          <input type="file" accept="image/*,video/*" onChange={e => { attach(e.target.files && e.target.files[0] ? e.target.files[0] : null); e.target.value = '' }} />
        </label>
        <input placeholder="Écrire un message" value={text} onChange={e => setText(e.target.value)} onKeyDown={e => { if (e.key === 'Enter') send() }} />
        <button onClick={send} disabled={!text.trim()}>Envoyer</button>
      </div>
    </div>
  )
}
