import { useCallback, useEffect, useState } from 'react'
import { supabase } from '../lib'
import { useAuth } from '../auth'
import { fcfa, when } from '../components'
import { uploadMedia } from '../social'

type Shop = { id: string; owner: string; owner_name: string | null; name: string; description: string | null; phone: string | null }
type Product = { id: string; shop_id: string; name: string; description: string | null; price_fcfa: number; image_url: string | null; stock: number | null; active: boolean }
type Order = { id: string; shop_id: string; buyer: string; buyer_name: string | null; product_name: string | null; qty: number; total_fcfa: number | null; phone: string; address: string | null; payment_ref: string | null; status: string; created_at: string }

const statusLabel: Record<string, string> = { nouvelle: 'Nouvelle', confirmee: 'Confirmée', livree: 'Livrée', annulee: 'Annulée' }

export default function Boutique() {
  const { userId } = useAuth()
  const [tab, setTab] = useState<'decouvrir' | 'commandes' | 'ma'>('decouvrir')
  const [shops, setShops] = useState<Shop[]>([])
  const [products, setProducts] = useState<Product[]>([])
  const [myOrders, setMyOrders] = useState<Order[]>([])
  const [shopOrders, setShopOrders] = useState<Order[]>([])
  const [buying, setBuying] = useState<Product | null>(null)
  const [err, setErr] = useState('')
  const [msg, setMsg] = useState('')

  // formulaire de commande
  const [qty, setQty] = useState(1)
  const [phone, setPhone] = useState('')
  const [address, setAddress] = useState('')
  const [payRef, setPayRef] = useState('')

  // ma boutique
  const [shopName, setShopName] = useState('')
  const [shopDesc, setShopDesc] = useState('')
  const [shopPhone, setShopPhone] = useState('')
  const [pName, setPName] = useState('')
  const [pPrice, setPPrice] = useState('')
  const [pStock, setPStock] = useState('')
  const [pFile, setPFile] = useState<File | null>(null)
  const [busy, setBusy] = useState(false)

  const myShop = shops.find(s => s.owner === userId) ?? null

  const load = useCallback(async () => {
    const s = await supabase.from('shops').select('*').order('created_at', { ascending: false })
    if (s.error) { setErr(s.error.message); return }
    const shopList = (s.data ?? []) as Shop[]
    setShops(shopList)
    const p = await supabase.from('products').select('*').order('created_at', { ascending: false }).limit(100)
    setProducts((p.data ?? []) as Product[])
    if (userId) {
      const mo = await supabase.from('orders').select('*').eq('buyer', userId).order('created_at', { ascending: false })
      setMyOrders((mo.data ?? []) as Order[])
      const mine = shopList.find(x => x.owner === userId)
      if (mine) {
        const so = await supabase.from('orders').select('*').eq('shop_id', mine.id).order('created_at', { ascending: false })
        setShopOrders((so.data ?? []) as Order[])
      }
    }
  }, [userId])

  useEffect(() => { load() }, [load])

  const shopOf = (id: string) => shops.find(s => s.id === id)
  const visible = products.filter(p => p.active)

  async function order() {
    if (!buying) return
    setErr(''); setMsg('')
    const r = await supabase.from('orders').insert({
      product_id: buying.id, qty, phone: phone.trim(), address: address.trim() || null, payment_ref: payRef.trim() || null,
    })
    if (r.error) { setErr(r.error.message); return }
    setBuying(null); setQty(1); setAddress(''); setPayRef('')
    setMsg('Commande envoyée. Le vendeur va la confirmer.')
    setTab('commandes')
    load()
  }

  async function createShop() {
    setErr('')
    const r = await supabase.from('shops').insert({ name: shopName.trim(), description: shopDesc.trim() || null, phone: shopPhone.trim() || null })
    if (r.error) { setErr(r.error.message); return }
    setShopName(''); setShopDesc(''); setShopPhone('')
    load()
  }

  async function addProduct() {
    if (!myShop || !userId) return
    setBusy(true); setErr('')
    let image: string | null = null
    if (pFile) {
      const up = await uploadMedia(pFile, userId)
      if (up.error) { setErr(up.error); setBusy(false); return }
      image = up.url
    }
    const r = await supabase.from('products').insert({
      shop_id: myShop.id, name: pName.trim(), price_fcfa: Number(pPrice),
      stock: pStock.trim() === '' ? null : Number(pStock), image_url: image,
    })
    if (r.error) setErr(r.error.message)
    else { setPName(''); setPPrice(''); setPStock(''); setPFile(null) }
    setBusy(false)
    load()
  }

  async function removeProduct(id: string) {
    if (!window.confirm('Supprimer ce produit ?')) return
    await supabase.from('products').delete().eq('id', id)
    load()
  }

  async function setStatus(id: string, status: string) {
    const r = await supabase.from('orders').update({ status }).eq('id', id)
    if (r.error) setErr(r.error.message)
    load()
  }

  const myProducts = myShop ? products.filter(p => p.shop_id === myShop.id) : []

  return (
    <>
      <h2>Boutique</h2>
      <div className="chips">
        <button className={tab === 'decouvrir' ? 'on' : ''} onClick={() => setTab('decouvrir')}>Découvrir</button>
        <button className={tab === 'commandes' ? 'on' : ''} onClick={() => setTab('commandes')}>Mes commandes</button>
        <button className={tab === 'ma' ? 'on' : ''} onClick={() => setTab('ma')}>Ma boutique</button>
      </div>
      {err && <p className="msg">{err}</p>}
      {msg && <p className="muted">{msg}</p>}

      {tab === 'decouvrir' && (
        <>
          {visible.length === 0 && <p className="muted">Aucun produit pour le moment. Ouvrez la première boutique dans « Ma boutique ».</p>}
          <div className="grid2">
            {visible.map(p => (
              <div className="prod" key={p.id}>
                <div className="img">{p.image_url ? <img src={p.image_url} alt="" loading="lazy" /> : 'Pas de photo'}</div>
                <div className="info">
                  <strong>{p.name}</strong>
                  <span className="price">{fcfa(p.price_fcfa)}</span>
                  <span className="muted">{shopOf(p.shop_id)?.name ?? 'Boutique'}</span>
                  <button className="small" onClick={() => { setBuying(p); setQty(1) }} disabled={p.stock !== null && p.stock <= 0}>
                    {p.stock !== null && p.stock <= 0 ? 'Épuisé' : 'Commander'}
                  </button>
                </div>
              </div>
            ))}
          </div>
        </>
      )}

      {tab === 'commandes' && (
        <div className="list">
          {myOrders.length === 0 && <p className="muted">Vous n'avez pas encore passé de commande.</p>}
          {myOrders.map(o => (
            <div className="card" key={o.id}>
              <div className="row"><strong>{o.product_name} × {o.qty}</strong><span className="badge">{statusLabel[o.status] ?? o.status}</span></div>
              <p className="muted">{fcfa(o.total_fcfa ?? 0)} · {shopOf(o.shop_id)?.name ?? 'Boutique'} · {when(o.created_at)}</p>
            </div>
          ))}
        </div>
      )}

      {tab === 'ma' && !myShop && (
        <div className="card form">
          <strong>Ouvrir ma boutique</strong>
          <input placeholder="Nom de la boutique" value={shopName} onChange={e => setShopName(e.target.value)} />
          <textarea placeholder="Description" value={shopDesc} onChange={e => setShopDesc(e.target.value)} />
          <input placeholder="Numéro Orange Money / Moov pour être payé" value={shopPhone} onChange={e => setShopPhone(e.target.value)} />
          <button onClick={createShop} disabled={!shopName.trim()}>Créer ma boutique</button>
          <p className="muted" style={{ margin: 0 }}>Plan gratuit : 5 produits. Premium : produits illimités.</p>
        </div>
      )}

      {tab === 'ma' && myShop && (
        <>
          <div className="card" style={{ marginBottom: 14 }}>
            <strong>{myShop.name}</strong>
            <p className="muted">{myShop.description}</p>
            <p className="muted">Paiement : {myShop.phone || 'numéro non renseigné'}</p>
          </div>

          <div className="card form" style={{ marginBottom: 14 }}>
            <strong>Ajouter un produit</strong>
            <input placeholder="Nom du produit" value={pName} onChange={e => setPName(e.target.value)} />
            <input placeholder="Prix en FCFA" type="number" value={pPrice} onChange={e => setPPrice(e.target.value)} />
            <input placeholder="Stock (laisser vide si illimité)" type="number" value={pStock} onChange={e => setPStock(e.target.value)} />
            <input type="file" accept="image/*" onChange={e => setPFile(e.target.files && e.target.files[0] ? e.target.files[0] : null)} />
            <button onClick={addProduct} disabled={busy || !pName.trim() || pPrice === ''}>{busy ? 'Envoi…' : 'Ajouter'}</button>
          </div>

          <h3>Mes produits</h3>
          {myProducts.length === 0 && <p className="muted">Aucun produit pour le moment.</p>}
          <div className="list">
            {myProducts.map(p => (
              <div className="card row" key={p.id}>
                <div><strong>{p.name}</strong><div className="muted">{fcfa(p.price_fcfa)} · stock {p.stock === null ? 'illimité' : p.stock}</div></div>
                <button className="small ghost" onClick={() => removeProduct(p.id)}>Supprimer</button>
              </div>
            ))}
          </div>

          <h3>Commandes reçues</h3>
          {shopOrders.length === 0 && <p className="muted">Aucune commande pour le moment.</p>}
          <div className="list">
            {shopOrders.map(o => (
              <div className="card" key={o.id}>
                <div className="row"><strong>{o.product_name} × {o.qty}</strong><span className="badge">{statusLabel[o.status] ?? o.status}</span></div>
                <p className="muted">{fcfa(o.total_fcfa ?? 0)} · {o.buyer_name || 'Client'} · {o.phone}</p>
                {o.address && <p className="muted">Adresse : {o.address}</p>}
                {o.payment_ref && <p className="muted">Référence de paiement : {o.payment_ref}</p>}
                <div className="row" style={{ justifyContent: 'flex-start' }}>
                  {o.status === 'nouvelle' && <button className="small" onClick={() => setStatus(o.id, 'confirmee')}>Confirmer</button>}
                  {o.status === 'confirmee' && <button className="small" onClick={() => setStatus(o.id, 'livree')}>Marquer livrée</button>}
                  {(o.status === 'nouvelle' || o.status === 'confirmee') && <button className="small ghost" onClick={() => setStatus(o.id, 'annulee')}>Annuler</button>}
                </div>
              </div>
            ))}
          </div>
        </>
      )}

      {buying && (
        <div className="sheet-back" onClick={() => setBuying(null)}>
          <div className="sheet" onClick={e => e.stopPropagation()}>
            <div className="sheet-head">
              <strong>{buying.name}</strong>
              <button className="small ghost" onClick={() => setBuying(null)}>Fermer</button>
            </div>
            <div className="pad">
              <span className="price" style={{ fontWeight: 700 }}>{fcfa(buying.price_fcfa * qty)}</span>
              <input type="number" min={1} value={qty} onChange={e => setQty(Math.max(1, Number(e.target.value) || 1))} />
              <input placeholder="Votre téléphone" value={phone} onChange={e => setPhone(e.target.value)} />
              <input placeholder="Adresse de livraison" value={address} onChange={e => setAddress(e.target.value)} />
              <p className="muted" style={{ margin: 0 }}>
                Payez {fcfa(buying.price_fcfa * qty)} par Orange Money ou Moov Africa au {shopOf(buying.shop_id)?.phone || '(numéro non renseigné par le vendeur)'}, puis entrez la référence reçue par SMS.
              </p>
              <input placeholder="Référence du paiement" value={payRef} onChange={e => setPayRef(e.target.value)} />
              <button onClick={order} disabled={!phone.trim()}>Envoyer la commande</button>
            </div>
          </div>
        </div>
      )}
    </>
  )
}
