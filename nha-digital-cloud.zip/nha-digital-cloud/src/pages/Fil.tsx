import { useCallback, useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { supabase } from '../lib'
import { useAuth } from '../auth'
import { Avatar, Comments, when } from '../components'
import { loadPosts, toggleLike, uploadMedia, type Post } from '../social'

type Live = { id: string; title: string; host_name: string | null }

export default function Fil() {
  const { userId, profile } = useAuth()
  const [posts, setPosts] = useState<Post[]>([])
  const [lives, setLives] = useState<Live[]>([])
  const [body, setBody] = useState('')
  const [file, setFile] = useState<File | null>(null)
  const [short, setShort] = useState(false)
  const [busy, setBusy] = useState(false)
  const [openCm, setOpenCm] = useState<string | null>(null)
  const [err, setErr] = useState('')

  const load = useCallback(async () => {
    const r = await loadPosts()
    setPosts(r.posts)
    if (r.error) setErr(r.error)
    const since = new Date(Date.now() - 12 * 3600 * 1000).toISOString()
    const lv = await supabase.from('rooms').select('id, title, host_name')
      .eq('kind', 'live').is('ended_at', null).gte('created_at', since)
    setLives((lv.data ?? []) as Live[])
  }, [])

  useEffect(() => { load() }, [load])

  async function publish() {
    if (!userId || (!body.trim() && !file)) return
    setBusy(true)
    setErr('')
    let url: string | null = null
    let type: string | null = null
    if (file) {
      const up = await uploadMedia(file, userId)
      if (up.error) { setErr(up.error); setBusy(false); return }
      url = up.url
      type = up.type
    }
    const ins = await supabase.from('posts').insert({
      body: body.trim() || null,
      media_url: url,
      media_type: type,
      is_short: short && type === 'video',
    })
    if (ins.error) setErr('Publication : ' + ins.error.message)
    else { setBody(''); setFile(null); setShort(false) }
    setBusy(false)
    load()
  }

  async function like(p: Post) {
    if (!userId) return
    const e = await toggleLike(p, userId)
    if (e) setErr(e)
    load()
  }

  async function remove(id: string) {
    if (!window.confirm('Supprimer cette publication ?')) return
    const r = await supabase.from('posts').delete().eq('id', id)
    if (r.error) setErr('Suppression : ' + r.error.message)
    load()
  }

  const isVideo = file !== null && file.type.startsWith('video')

  return (
    <>
      {lives.map(l => (
        <Link className="live-banner" to="/reunions" key={l.id}>
          <span><span className="dot" />En direct : {l.title}</span>
          <strong>Rejoindre</strong>
        </Link>
      ))}

      <div className="card compose">
        <textarea placeholder="Quoi de neuf ?" value={body} onChange={e => setBody(e.target.value)} />
        <div className="opts">
          <input type="file" accept="image/*,video/*" onChange={e => { setFile(e.target.files && e.target.files[0] ? e.target.files[0] : null); setShort(false) }} />
          {isVideo && (
            <label><input type="checkbox" checked={short} onChange={e => setShort(e.target.checked)} /> Publier aussi comme short</label>
          )}
        </div>
        <button onClick={publish} disabled={busy || (!body.trim() && !file)}>{busy ? 'Envoi en cours…' : 'Publier'}</button>
      </div>

      {err && <p className="msg">{err}</p>}
      {posts.length === 0 && <p className="muted">Aucune publication pour le moment. Soyez le premier à publier.</p>}

      <div className="feed">
        {posts.map(p => (
          <article className="post" key={p.id}>
            <div className="post-head">
              <Avatar name={p.author_name} />
              <div>
                <strong>{p.author_name || 'Membre'}</strong>
                <small>{when(p.created_at)}</small>
              </div>
            </div>
            {p.body && <div className="post-body">{p.body}</div>}
            {p.media_url && p.media_type === 'image' && <img className="post-media" src={p.media_url} alt="" loading="lazy" />}
            {p.media_url && p.media_type === 'video' && <video className="post-media" src={p.media_url} controls playsInline preload="metadata" />}
            <div className="post-actions">
              <button className={userId && p.likes.includes(userId) ? 'small' : 'small ghost'} onClick={() => like(p)}>J'aime ({p.likes.length})</button>
              <button className="small ghost" onClick={() => setOpenCm(openCm === p.id ? null : p.id)}>Commentaires ({p.commentCount})</button>
              {profile && (profile.role === 'admin' || p.author === userId) && (
                <button className="small ghost" onClick={() => remove(p.id)}>Supprimer</button>
              )}
            </div>
            {openCm === p.id && <Comments postId={p.id} onChanged={load} />}
          </article>
        ))}
      </div>
    </>
  )
}
