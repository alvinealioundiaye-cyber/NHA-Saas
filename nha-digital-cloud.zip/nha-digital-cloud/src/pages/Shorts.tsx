import { useCallback, useEffect, useRef, useState } from 'react'
import { Link } from 'react-router-dom'
import { useAuth } from '../auth'
import { Comments, Icon, icons } from '../components'
import { loadPosts, toggleLike, type Post } from '../social'

function ShortItem(props: {
  p: Post
  muted: boolean
  liked: boolean
  onToggleMute: () => void
  onLike: () => void
  onComment: () => void
}) {
  const { p, muted, liked, onToggleMute, onLike, onComment } = props
  const ref = useRef<HTMLVideoElement>(null)

  useEffect(() => {
    const v = ref.current
    if (!v) return
    const io = new IntersectionObserver(entries => {
      entries.forEach(en => {
        if (en.isIntersecting) v.play().catch(() => {})
        else v.pause()
      })
    }, { threshold: 0.7 })
    io.observe(v)
    return () => io.disconnect()
  }, [])

  useEffect(() => { if (ref.current) ref.current.muted = muted }, [muted])

  return (
    <section className="short">
      <video ref={ref} src={p.media_url ?? ''} loop playsInline muted preload="metadata" onClick={onToggleMute} />
      {muted && <div className="short-hint">Son coupé · touchez pour activer</div>}
      <div className="short-info">
        <strong>{p.author_name || 'Membre'}</strong>
        {p.body && <div>{p.body}</div>}
      </div>
      <div className="short-rail">
        <button className={liked ? 'liked' : ''} onClick={onLike} aria-label="J'aime"><Icon d={icons.heart} /></button>
        <span>{p.likes.length}</span>
        <button onClick={onComment} aria-label="Commentaires"><Icon d={icons.chat} /></button>
        <span>{p.commentCount}</span>
      </div>
    </section>
  )
}

export default function Shorts() {
  const { userId } = useAuth()
  const [posts, setPosts] = useState<Post[]>([])
  const [muted, setMuted] = useState(true)
  const [cmFor, setCmFor] = useState<string | null>(null)
  const [err, setErr] = useState('')

  const load = useCallback(async () => {
    const r = await loadPosts()
    setPosts(r.posts.filter(p => p.is_short && p.media_type === 'video' && p.media_url))
    if (r.error) setErr(r.error)
  }, [])

  useEffect(() => { load() }, [load])

  async function like(p: Post) {
    if (!userId) return
    await toggleLike(p, userId)
    load()
  }

  return (
    <div className="screen">
      <Link className="short-plus" to="/fil">+ Publier</Link>
      {posts.length === 0 ? (
        <div className="empty-dark">
          <div>
            <h2 style={{ color: '#fff' }}>Aucun short pour le moment</h2>
            <p>{err || 'Publiez une vidéo depuis le fil en cochant « Publier aussi comme short ».'}</p>
          </div>
        </div>
      ) : (
        <div className="shorts">
          {posts.map(p => (
            <ShortItem
              key={p.id}
              p={p}
              muted={muted}
              liked={userId !== null && p.likes.includes(userId)}
              onToggleMute={() => setMuted(!muted)}
              onLike={() => like(p)}
              onComment={() => setCmFor(p.id)}
            />
          ))}
        </div>
      )}
      {cmFor && (
        <div className="sheet-back" onClick={() => setCmFor(null)}>
          <div className="sheet" onClick={e => e.stopPropagation()}>
            <div className="sheet-head">
              <strong>Commentaires</strong>
              <button className="small ghost" onClick={() => setCmFor(null)}>Fermer</button>
            </div>
            <Comments postId={cmFor} onChanged={load} />
          </div>
        </div>
      )}
    </div>
  )
}
