import { useCallback, useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { supabase } from '../lib'
import { Avatar, when } from '../components'

type Conv = { conv_id: string; conv_is_group: boolean; conv_title: string; conv_last_body: string | null; conv_last_at: string }
type Member = { member_id: string; member_name: string }

export default function Messages() {
  const nav = useNavigate()
  const [convs, setConvs] = useState<Conv[]>([])
  const [mode, setMode] = useState<'list' | 'direct' | 'group'>('list')
  const [q, setQ] = useState('')
  const [members, setMembers] = useState<Member[]>([])
  const [picked, setPicked] = useState<string[]>([])
  const [groupName, setGroupName] = useState('')
  const [err, setErr] = useState('')

  const load = useCallback(async () => {
    const r = await supabase.rpc('my_conversations')
    if (r.error) setErr(r.error.message)
    else setConvs((r.data ?? []) as Conv[])
  }, [])

  useEffect(() => { load() }, [load])

  useEffect(() => {
    if (mode === 'list') return
    const t = setTimeout(async () => {
      const r = await supabase.rpc('search_members', { q })
      if (r.error) setErr(r.error.message)
      else setMembers((r.data ?? []) as Member[])
    }, 250)
    return () => clearTimeout(t)
  }, [mode, q])

  async function startDirect(id: string) {
    const r = await supabase.rpc('start_direct', { other: id })
    if (r.error) { setErr(r.error.message); return }
    nav('/messages/' + (r.data as string))
  }

  async function createGroup() {
    const r = await supabase.rpc('create_group', { group_name: groupName.trim(), member_ids: picked })
    if (r.error) { setErr(r.error.message); return }
    nav('/messages/' + (r.data as string))
  }

  function toggle(id: string) {
    setPicked(picked.includes(id) ? picked.filter(x => x !== id) : [...picked, id])
  }

  if (mode !== 'list') {
    return (
      <>
        <div className="row" style={{ marginBottom: 10 }}>
          <h2 style={{ margin: 0 }}>{mode === 'direct' ? 'Nouveau message' : 'Nouveau groupe'}</h2>
          <button className="small ghost" onClick={() => { setMode('list'); setPicked([]); setQ('') }}>Retour</button>
        </div>
        {err && <p className="msg">{err}</p>}
        {mode === 'group' && <input placeholder="Nom du groupe" value={groupName} onChange={e => setGroupName(e.target.value)} style={{ marginBottom: 10 }} />}
        <input placeholder="Chercher un membre par nom ou e-mail" value={q} onChange={e => setQ(e.target.value)} />
        <div style={{ marginTop: 8 }}>
          {members.length === 0 && <p className="muted">Aucun membre trouvé.</p>}
          {members.map(m => mode === 'direct' ? (
            <button className="conv" key={m.member_id} onClick={() => startDirect(m.member_id)}>
              <Avatar name={m.member_name} />
              <span className="grow"><strong>{m.member_name}</strong></span>
            </button>
          ) : (
            <label className="pick" key={m.member_id}>
              <input type="checkbox" checked={picked.includes(m.member_id)} onChange={() => toggle(m.member_id)} />
              <Avatar name={m.member_name} size={32} />
              <span>{m.member_name}</span>
            </label>
          ))}
        </div>
        {mode === 'group' && (
          <button style={{ marginTop: 12, width: '100%' }} onClick={createGroup} disabled={!groupName.trim() || picked.length === 0}>
            Créer le groupe ({picked.length})
          </button>
        )}
      </>
    )
  }

  return (
    <>
      <div className="row" style={{ marginBottom: 10 }}>
        <h2 style={{ margin: 0 }}>Messages</h2>
        <div className="row" style={{ gap: 8 }}>
          <button className="small" onClick={() => setMode('direct')}>Nouveau</button>
          <button className="small ghost" onClick={() => setMode('group')}>Groupe</button>
        </div>
      </div>
      {err && <p className="msg">{err}</p>}
      {convs.length === 0 && <p className="muted">Aucune discussion. Appuyez sur « Nouveau » pour écrire à un membre.</p>}
      {convs.map(c => (
        <button className="conv" key={c.conv_id} onClick={() => nav('/messages/' + c.conv_id)}>
          <Avatar name={c.conv_title} />
          <span className="grow">
            <strong>{c.conv_title}</strong>
            <span className="last">{c.conv_last_body || 'Nouvelle discussion'}</span>
          </span>
          <small>{when(c.conv_last_at)}</small>
        </button>
      ))}
    </>
  )
}
