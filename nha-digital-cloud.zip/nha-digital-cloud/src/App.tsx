import { NavLink, Navigate, Route, Routes, useLocation } from 'react-router-dom'
import { useAuth } from './auth'
import { Icon, Logo, icons } from './components'
import Login from './pages/Login'
import Pending from './pages/Pending'
import Fil from './pages/Fil'
import Shorts from './pages/Shorts'
import Messages from './pages/Messages'
import Chat from './pages/Chat'
import Boutique from './pages/Boutique'
import Reunions from './pages/Reunions'
import Plus from './pages/Plus'
import Academie from './pages/Academie'
import Abonnement from './pages/Abonnement'
import Users from './pages/Users'
import Soon from './pages/Soon'

const tabs = [
  { to: '/fil', label: 'Fil', icon: icons.home },
  { to: '/shorts', label: 'Shorts', icon: icons.play },
  { to: '/messages', label: 'Messages', icon: icons.chat },
  { to: '/boutique', label: 'Boutique', icon: icons.shop },
  { to: '/plus', label: 'Plus', icon: icons.menu },
]

export default function App() {
  const { loading, userId, profile } = useAuth()
  const { pathname } = useLocation()

  if (loading) return <div className="center">Chargement…</div>
  if (!userId) return <Login />
  if (!profile || profile.role === 'pending') return <Pending />

  const chatMode = pathname.startsWith('/messages/')
  const fullScreen = chatMode || pathname === '/shorts'

  return (
    <div className={chatMode ? 'shell chatmode' : 'shell'}>
      <header className="topbar">
        <Logo />
        <span className="wordmark">Omonia</span>
      </header>
      <nav className="tabbar">
        {tabs.map(t => (
          <NavLink key={t.to} to={t.to} className={({ isActive }) => (isActive || (t.to === '/messages' && chatMode) ? 'active' : '')}>
            <Icon d={t.icon} />
            <span>{t.label}</span>
          </NavLink>
        ))}
      </nav>
      <main className={fullScreen ? '' : 'content'}>
        <Routes>
          <Route path="/" element={<Navigate to="/fil" replace />} />
          <Route path="/fil" element={<Fil />} />
          <Route path="/shorts" element={<Shorts />} />
          <Route path="/messages" element={<Messages />} />
          <Route path="/messages/:id" element={<Chat />} />
          <Route path="/boutique" element={<Boutique />} />
          <Route path="/reunions" element={<Reunions />} />
          <Route path="/plus" element={<Plus />} />
          <Route path="/academie" element={<Academie />} />
          <Route path="/abonnement" element={<Abonnement />} />
          <Route path="/ia" element={<Soon title="Assistant IA" text="Aide à la création de cours et de contenus." />} />
          {profile.role === 'admin' && <Route path="/utilisateurs" element={<Users />} />}
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </main>
    </div>
  )
}
