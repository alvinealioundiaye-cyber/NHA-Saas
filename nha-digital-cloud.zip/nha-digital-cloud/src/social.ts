import { supabase } from './lib'

export type Post = {
  id: string
  author: string
  author_name: string | null
  body: string | null
  media_url: string | null
  media_type: string | null
  is_short: boolean
  created_at: string
  likes: string[]
  commentCount: number
}

export async function loadPosts(): Promise<{ posts: Post[]; error: string }> {
  const res = await supabase.from('posts').select('*').order('created_at', { ascending: false }).limit(60)
  if (res.error) return { posts: [], error: 'Chargement : ' + res.error.message }
  const rows = (res.data ?? []) as Omit<Post, 'likes' | 'commentCount'>[]
  if (rows.length === 0) return { posts: [], error: '' }
  const ids = rows.map(r => r.id)
  const likesRes = await supabase.from('post_likes').select('post_id, user_id').in('post_id', ids)
  const comRes = await supabase.from('post_comments').select('post_id').in('post_id', ids)
  const likes = (likesRes.data ?? []) as { post_id: string; user_id: string }[]
  const coms = (comRes.data ?? []) as { post_id: string }[]
  const posts = rows.map(r => ({
    ...r,
    likes: likes.filter(l => l.post_id === r.id).map(l => l.user_id),
    commentCount: coms.filter(c => c.post_id === r.id).length,
  }))
  return { posts, error: '' }
}

export async function toggleLike(p: Post, userId: string): Promise<string> {
  const liked = p.likes.includes(userId)
  const r = liked
    ? await supabase.from('post_likes').delete().eq('post_id', p.id).eq('user_id', userId)
    : await supabase.from('post_likes').insert({ post_id: p.id })
  return r.error ? r.error.message : ''
}

export async function uploadMedia(file: File, userId: string): Promise<{ url: string; type: 'image' | 'video'; error: string }> {
  const safe = file.name.replace(/[^a-zA-Z0-9._-]/g, '_')
  const path = userId + '/' + Date.now() + '-' + safe
  const up = await supabase.storage.from('media').upload(path, file, { contentType: file.type })
  if (up.error) return { url: '', type: 'image', error: 'Envoi du fichier : ' + up.error.message }
  const url = supabase.storage.from('media').getPublicUrl(path).data.publicUrl
  return { url, type: file.type.startsWith('video') ? 'video' : 'image', error: '' }
}
