import { useCallback, useEffect, useState } from 'react'
import { supabase } from './lib'

export const when = (d: string) => new Date(d).toLocaleString('fr-FR', { dateStyle: 'short', timeStyle: 'short' })
export const fcfa = (n: number) => n.toLocaleString('fr-FR') + ' FCFA'

export function Logo({ size = 28 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 32 32" aria-hidden="true">
      <circle cx="12" cy="16" r="9" fill="none" stroke="#F2B134" strokeWidth="3" />
      <circle cx="20" cy="16" r="9" fill="none" stroke="currentColor" strokeWidth="3" opacity=".92" />
    </svg>
  )
}

const palette = ['#17365D', '#1F6F8B', '#8A4F7D', '#A8571B', '#2E7D5B', '#5B4B8A']

export function Avatar({ name, size = 38 }: { name: string | null | undefined; size?: number }) {
  const n = (name && name.trim()) || '?'
  let h = 0
  for (let i = 0; i < n.length; i++) h = (h * 31 + n.charCodeAt(i)) % palette.length
  return (
    <span className="avatar" style={{ width: size, height: size, background: palette[h], fontSize: size * 0.42 }}>
      {n.charAt(0).toUpperCase()}
    </span>
  )
}

export function Icon({ d }: { d: string }) {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinejoin="round" strokeLinecap="round" aria-hidden="true">
      <path d={d} />
    </svg>
  )
}

export const icons = {
  home: 'M3 11l9-8 9 8v10h-6v-6H9v6H3z',
  play: 'M6 4l14 8-14 8z',
  chat: 'M4 4h16v12H9l-5 4z',
  shop: 'M4 7h16l-1 13H5zM8 7a4 4 0 018 0',
  menu: 'M4 6h16M4 12h16M4 18h16',
  heart: 'M12 21s-7-4.5-9.5-9C1 8.5 3 5 6.5 5c2 0 3.5 1 5.5 3 2-2 3.5-3 5.5-3C21 5 23 8.5 21.5 12 19 16.5 12 21 12 21z',
}

type CommentRow = { id: string; author_name: string | null; body: string; created_at: string }

export function Comments({ postId, onChanged }: { postId: string; onChanged: () => void }) {
  const [list, setList] = useState<CommentRow[]>([])
  const [text, setText] = useState('')

  const load = useCallback(async () => {
    const r = await supabase.from('post_comments').select('id, author_name, body, created_at')
      .eq('post_id', postId).order('created_at', { ascending: true })
    setList((r.data ?? []) as CommentRow[])
  }, [postId])

  useEffect(() => { load() }, [load])

  async function send() {
    if (!text.trim()) return
    await supabase.from('post_comments').insert({ post_id: postId, body: text.trim() })
    setText('')
    load()
    onChanged()
  }

  return (
    <div className="cm">
      {list.length === 0 && <small>Aucun commentaire pour le moment.</small>}
      {list.map(c => (
        <div key={c.id}>
          <small>{(c.author_name || 'Membre') + ' · ' + when(c.created_at)}</small>
          <p>{c.body}</p>
        </div>
      ))}
      <div className="cm-row">
        <input placeholder="Écrire un commentaire" value={text} onChange={e => setText(e.target.value)} />
        <button onClick={send} disabled={!text.trim()}>Envoyer</button>
      </div>
    </div>
  )
}
