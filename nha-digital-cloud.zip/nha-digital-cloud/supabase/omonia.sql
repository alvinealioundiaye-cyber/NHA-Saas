-- Plans gratuit / premium + demandes d'abonnement (peut être relancé sans erreur)

alter table public.profiles add column if not exists plan text not null default 'gratuit';
alter table public.profiles add column if not exists plan_expires_at timestamptz;

create or replace function public.is_premium(uid uuid) returns boolean
language sql security definer set search_path = public stable as $$
  select exists (select 1 from public.profiles
    where id = uid and plan = 'premium' and plan_expires_at > now())
$$;

-- Plan gratuit : 3 publications par jour. Premium et admin : illimité.
create or replace function public.check_post_limit() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if public.is_admin() or public.is_premium(auth.uid()) then
    return new;
  end if;
  if (select count(*) from public.posts
      where author = auth.uid() and created_at >= date_trunc('day', now())) >= 3 then
    raise exception 'Limite du plan gratuit atteinte : 3 publications par jour. Passez à Premium pour publier sans limite.';
  end if;
  return new;
end $$;

drop trigger if exists posts_limit on public.posts;
create trigger posts_limit before insert on public.posts
  for each row execute function public.check_post_limit();

create table if not exists public.app_settings (
  key text primary key,
  value text not null
);
insert into public.app_settings (key, value) values ('prix_fcfa', '1000'), ('numero_paiement', '')
on conflict (key) do nothing;

create table if not exists public.subscription_requests (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null default auth.uid() references auth.users on delete cascade,
  user_name text,
  operateur text not null,
  reference text not null,
  montant integer,
  status text not null default 'en_attente',
  created_at timestamptz not null default now()
);

create or replace function public.set_request_name() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  new.user_name := coalesce(
    (select coalesce(nullif(full_name, ''), email) from public.profiles where id = auth.uid()), 'Membre');
  new.status := 'en_attente';
  return new;
end $$;

drop trigger if exists requests_name on public.subscription_requests;
create trigger requests_name before insert on public.subscription_requests
  for each row execute function public.set_request_name();

alter table public.app_settings enable row level security;
alter table public.subscription_requests enable row level security;

drop policy if exists "lire reglages" on public.app_settings;
drop policy if exists "admin ajoute reglages" on public.app_settings;
drop policy if exists "admin modifie reglages" on public.app_settings;
create policy "lire reglages" on public.app_settings for select to authenticated using (public.is_member());
create policy "admin ajoute reglages" on public.app_settings for insert to authenticated with check (public.is_admin());
create policy "admin modifie reglages" on public.app_settings for update to authenticated using (public.is_admin());

drop policy if exists "voir demandes" on public.subscription_requests;
drop policy if exists "creer demande" on public.subscription_requests;
create policy "voir demandes" on public.subscription_requests for select to authenticated
  using (user_id = auth.uid() or public.is_admin());
create policy "creer demande" on public.subscription_requests for insert to authenticated
  with check (public.is_member() and user_id = auth.uid());

create or replace function public.approve_subscription(req uuid, days integer default 30) returns void
language plpgsql security definer set search_path = public as $$
declare uid uuid;
begin
  if not public.is_admin() then raise exception 'Réservé à l''administrateur'; end if;
  select user_id into uid from public.subscription_requests where id = req and status = 'en_attente';
  if uid is null then raise exception 'Demande introuvable ou déjà traitée'; end if;
  update public.subscription_requests set status = 'approuve' where id = req;
  update public.profiles
    set plan = 'premium',
        plan_expires_at = greatest(now(), coalesce(plan_expires_at, now())) + make_interval(days => days)
    where id = uid;
end $$;

create or replace function public.reject_subscription(req uuid) returns void
language plpgsql security definer set search_path = public as $$
begin
  if not public.is_admin() then raise exception 'Réservé à l''administrateur'; end if;
  update public.subscription_requests set status = 'refuse' where id = req and status = 'en_attente';
end $$;

notify pgrst, 'reload schema';

-- =====================================================================
-- OMONIA : messagerie, boutiques, réunions et lives (relançable sans erreur)
-- =====================================================================

create or replace function public.is_member() returns boolean
language sql security definer set search_path = public stable as $$
  select exists (select 1 from public.profiles where id = auth.uid() and role <> 'pending')
$$;

insert into public.app_settings (key, value) values ('jitsi_url', 'https://meet.jit.si')
on conflict (key) do nothing;

-- ---------- Messagerie ----------
create table if not exists public.conversations (
  id uuid primary key default gen_random_uuid(),
  is_group boolean not null default false,
  name text,
  created_by uuid default auth.uid() references auth.users on delete set null,
  created_at timestamptz not null default now()
);
create table if not exists public.conversation_members (
  conversation_id uuid not null references public.conversations on delete cascade,
  user_id uuid not null references auth.users on delete cascade,
  primary key (conversation_id, user_id)
);
create table if not exists public.messages (
  id uuid primary key default gen_random_uuid(),
  conversation_id uuid not null references public.conversations on delete cascade,
  sender uuid not null default auth.uid() references auth.users on delete cascade,
  sender_name text,
  body text,
  media_url text,
  media_type text,
  created_at timestamptz not null default now()
);

create or replace function public.is_conv_member(cid uuid) returns boolean
language sql security definer set search_path = public stable as $$
  select exists (select 1 from public.conversation_members where conversation_id = cid and user_id = auth.uid())
$$;

create or replace function public.fn_message_defaults() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  new.sender_name := coalesce(
    (select coalesce(nullif(full_name, ''), split_part(email, '@', 1)) from public.profiles where id = auth.uid()), 'Membre');
  return new;
end $$;
drop trigger if exists messages_defaults on public.messages;
create trigger messages_defaults before insert on public.messages
  for each row execute function public.fn_message_defaults();

alter table public.conversations enable row level security;
alter table public.conversation_members enable row level security;
alter table public.messages enable row level security;

drop policy if exists "voir conversations" on public.conversations;
create policy "voir conversations" on public.conversations for select to authenticated using (public.is_conv_member(id));
drop policy if exists "voir membres" on public.conversation_members;
create policy "voir membres" on public.conversation_members for select to authenticated using (public.is_conv_member(conversation_id));
drop policy if exists "lire messages" on public.messages;
drop policy if exists "ecrire message" on public.messages;
drop policy if exists "supprimer message" on public.messages;
create policy "lire messages" on public.messages for select to authenticated using (public.is_conv_member(conversation_id));
create policy "ecrire message" on public.messages for insert to authenticated
  with check (public.is_conv_member(conversation_id) and sender = auth.uid());
create policy "supprimer message" on public.messages for delete to authenticated using (sender = auth.uid() or public.is_admin());

create or replace function public.search_members(q text default '')
returns table(member_id uuid, member_name text)
language sql security definer set search_path = public stable as $$
  select p.id, coalesce(nullif(p.full_name, ''), split_part(p.email, '@', 1))
  from public.profiles p
  where public.is_member() and p.role <> 'pending' and p.id <> auth.uid()
    and (coalesce(q, '') = '' or p.full_name ilike '%' || q || '%' or p.email ilike '%' || q || '%')
  order by 2
  limit 30
$$;

create or replace function public.start_direct(other uuid) returns uuid
language plpgsql security definer set search_path = public as $$
declare cid uuid;
begin
  if not public.is_member() then raise exception 'Compte non validé'; end if;
  select c.id into cid from public.conversations c
  where not c.is_group
    and exists (select 1 from public.conversation_members a where a.conversation_id = c.id and a.user_id = auth.uid())
    and exists (select 1 from public.conversation_members b where b.conversation_id = c.id and b.user_id = other)
  limit 1;
  if cid is null then
    insert into public.conversations (is_group, created_by) values (false, auth.uid()) returning id into cid;
    insert into public.conversation_members (conversation_id, user_id) values (cid, auth.uid()), (cid, other);
  end if;
  return cid;
end $$;

create or replace function public.create_group(group_name text, member_ids uuid[]) returns uuid
language plpgsql security definer set search_path = public as $$
declare cid uuid;
begin
  if not public.is_member() then raise exception 'Compte non validé'; end if;
  insert into public.conversations (is_group, name, created_by) values (true, group_name, auth.uid()) returning id into cid;
  insert into public.conversation_members (conversation_id, user_id)
  select cid, x from (select auth.uid() as x union select unnest(member_ids)) t where x is not null;
  return cid;
end $$;

create or replace function public.my_conversations()
returns table(conv_id uuid, conv_is_group boolean, conv_title text, conv_last_body text, conv_last_at timestamptz)
language sql security definer set search_path = public stable as $$
  select c.id, c.is_group,
    case when c.is_group then coalesce(c.name, 'Groupe')
      else coalesce((select coalesce(nullif(p.full_name, ''), split_part(p.email, '@', 1))
                     from public.conversation_members m2 join public.profiles p on p.id = m2.user_id
                     where m2.conversation_id = c.id and m2.user_id <> auth.uid() limit 1), 'Discussion') end,
    (select case when m.body is null then 'Média' else m.body end
       from public.messages m where m.conversation_id = c.id order by m.created_at desc limit 1),
    coalesce((select max(m.created_at) from public.messages m where m.conversation_id = c.id), c.created_at)
  from public.conversations c
  where exists (select 1 from public.conversation_members cm where cm.conversation_id = c.id and cm.user_id = auth.uid())
  order by 5 desc
$$;

do $$ begin
  alter publication supabase_realtime add table public.messages;
exception when others then null;
end $$;

-- ---------- Boutiques ----------
create table if not exists public.shops (
  id uuid primary key default gen_random_uuid(),
  owner uuid not null unique default auth.uid() references auth.users on delete cascade,
  owner_name text,
  name text not null,
  description text,
  phone text,
  created_at timestamptz not null default now()
);
create table if not exists public.products (
  id uuid primary key default gen_random_uuid(),
  shop_id uuid not null references public.shops on delete cascade,
  name text not null,
  description text,
  price_fcfa integer not null check (price_fcfa >= 0),
  image_url text,
  stock integer,
  active boolean not null default true,
  created_at timestamptz not null default now()
);
create table if not exists public.orders (
  id uuid primary key default gen_random_uuid(),
  shop_id uuid references public.shops on delete cascade,
  product_id uuid references public.products on delete set null,
  buyer uuid not null default auth.uid() references auth.users on delete cascade,
  buyer_name text,
  product_name text,
  qty integer not null default 1 check (qty > 0),
  total_fcfa integer,
  phone text not null,
  address text,
  payment_ref text,
  status text not null default 'nouvelle',
  created_at timestamptz not null default now()
);

create or replace function public.owns_shop(sid uuid) returns boolean
language sql security definer set search_path = public stable as $$
  select exists (select 1 from public.shops where id = sid and owner = auth.uid())
$$;

create or replace function public.fn_shop_defaults() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  new.owner_name := coalesce(
    (select coalesce(nullif(full_name, ''), split_part(email, '@', 1)) from public.profiles where id = auth.uid()), 'Membre');
  return new;
end $$;
drop trigger if exists shops_defaults on public.shops;
create trigger shops_defaults before insert on public.shops
  for each row execute function public.fn_shop_defaults();

create or replace function public.fn_product_limit() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if public.is_admin() or public.is_premium(auth.uid()) then return new; end if;
  if (select count(*) from public.products where shop_id = new.shop_id) >= 5 then
    raise exception 'Plan gratuit : 5 produits maximum. Passez à Premium pour en ajouter davantage.';
  end if;
  return new;
end $$;
drop trigger if exists products_limit on public.products;
create trigger products_limit before insert on public.products
  for each row execute function public.fn_product_limit();

create or replace function public.fn_order_defaults() returns trigger
language plpgsql security definer set search_path = public as $$
declare p record;
begin
  select * into p from public.products where id = new.product_id and active;
  if not found then raise exception 'Produit introuvable'; end if;
  if p.stock is not null and p.stock < new.qty then raise exception 'Stock insuffisant'; end if;
  new.shop_id := p.shop_id;
  new.product_name := p.name;
  new.total_fcfa := p.price_fcfa * new.qty;
  new.status := 'nouvelle';
  new.buyer_name := coalesce(
    (select coalesce(nullif(full_name, ''), split_part(email, '@', 1)) from public.profiles where id = auth.uid()), 'Client');
  if p.stock is not null then
    update public.products set stock = stock - new.qty where id = p.id;
  end if;
  return new;
end $$;
drop trigger if exists orders_defaults on public.orders;
create trigger orders_defaults before insert on public.orders
  for each row execute function public.fn_order_defaults();

create or replace function public.fn_order_lock() returns trigger
language plpgsql as $$
begin
  new.shop_id := old.shop_id; new.product_id := old.product_id; new.buyer := old.buyer;
  new.buyer_name := old.buyer_name; new.product_name := old.product_name; new.qty := old.qty;
  new.total_fcfa := old.total_fcfa; new.phone := old.phone; new.address := old.address;
  new.payment_ref := old.payment_ref; new.created_at := old.created_at;
  return new;
end $$;
drop trigger if exists orders_lock on public.orders;
create trigger orders_lock before update on public.orders
  for each row execute function public.fn_order_lock();

alter table public.shops enable row level security;
alter table public.products enable row level security;
alter table public.orders enable row level security;

drop policy if exists "voir boutiques" on public.shops;
drop policy if exists "creer boutique" on public.shops;
drop policy if exists "modifier boutique" on public.shops;
drop policy if exists "supprimer boutique" on public.shops;
create policy "voir boutiques" on public.shops for select to authenticated using (public.is_member());
create policy "creer boutique" on public.shops for insert to authenticated with check (public.is_member() and owner = auth.uid());
create policy "modifier boutique" on public.shops for update to authenticated using (owner = auth.uid());
create policy "supprimer boutique" on public.shops for delete to authenticated using (owner = auth.uid() or public.is_admin());

drop policy if exists "voir produits" on public.products;
drop policy if exists "creer produit" on public.products;
drop policy if exists "modifier produit" on public.products;
drop policy if exists "supprimer produit" on public.products;
create policy "voir produits" on public.products for select to authenticated using (public.is_member() and (active or public.owns_shop(shop_id)));
create policy "creer produit" on public.products for insert to authenticated with check (public.owns_shop(shop_id));
create policy "modifier produit" on public.products for update to authenticated using (public.owns_shop(shop_id));
create policy "supprimer produit" on public.products for delete to authenticated using (public.owns_shop(shop_id) or public.is_admin());

drop policy if exists "voir commandes" on public.orders;
drop policy if exists "passer commande" on public.orders;
drop policy if exists "traiter commande" on public.orders;
create policy "voir commandes" on public.orders for select to authenticated
  using (buyer = auth.uid() or public.owns_shop(shop_id) or public.is_admin());
create policy "passer commande" on public.orders for insert to authenticated
  with check (public.is_member() and buyer = auth.uid());
create policy "traiter commande" on public.orders for update to authenticated using (public.owns_shop(shop_id));

-- ---------- Réunions et lives ----------
create table if not exists public.rooms (
  id uuid primary key default gen_random_uuid(),
  host uuid not null default auth.uid() references auth.users on delete cascade,
  host_name text,
  title text not null,
  kind text not null default 'reunion' check (kind in ('reunion', 'live')),
  code text,
  ended_at timestamptz,
  created_at timestamptz not null default now()
);

create or replace function public.fn_room_defaults() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if new.kind = 'live' and not (public.is_admin() or public.is_premium(auth.uid())) then
    raise exception 'Les lives sont réservés aux abonnés Premium.';
  end if;
  new.host_name := coalesce(
    (select coalesce(nullif(full_name, ''), split_part(email, '@', 1)) from public.profiles where id = auth.uid()), 'Membre');
  new.code := 'omonia-' || substr(md5(random()::text || clock_timestamp()::text), 1, 12);
  return new;
end $$;
drop trigger if exists rooms_defaults on public.rooms;
create trigger rooms_defaults before insert on public.rooms
  for each row execute function public.fn_room_defaults();

alter table public.rooms enable row level security;
drop policy if exists "voir salles" on public.rooms;
drop policy if exists "creer salle" on public.rooms;
drop policy if exists "terminer salle" on public.rooms;
create policy "voir salles" on public.rooms for select to authenticated using (public.is_member());
create policy "creer salle" on public.rooms for insert to authenticated with check (public.is_member() and host = auth.uid());
create policy "terminer salle" on public.rooms for update to authenticated using (host = auth.uid() or public.is_admin());

-- Les nouveaux comptes sont acceptés automatiquement (le premier devient administrateur)
create or replace function public.handle_new_user() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id, email, full_name, role)
  values (
    new.id, new.email, new.raw_user_meta_data->>'full_name',
    case when (select count(*) from public.profiles) = 0 then 'admin'::app_role else 'student'::app_role end
  );
  return new;
end $$;
update public.profiles set role = 'student' where role = 'pending';

notify pgrst, 'reload schema';
