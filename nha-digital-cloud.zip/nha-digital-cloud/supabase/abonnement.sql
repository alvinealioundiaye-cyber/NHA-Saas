-- Plans gratuit / premium + demandes d'abonnement (peut être relancé sans erreur)

alter table public.profiles add column if not exists plan text not null default 'gratuit';
alter table public.profiles add column if not exists plan_expires_at timestamptz;

create or replace function public.is_premium(uid uuid) returns boolean
language sql security definer set search_path = public stable as $$
  select exists (select 1 from public.profiles
    where id = uid and plan = 'premium' and plan_expires_at > now())
$$;

-- Plan gratuit : 3 publications par jour. Premium et admin : illimité.
create or replace function public.check_post_limit() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if public.is_admin() or public.is_premium(auth.uid()) then
    return new;
  end if;
  if (select count(*) from public.posts
      where author = auth.uid() and created_at >= date_trunc('day', now())) >= 3 then
    raise exception 'Limite du plan gratuit atteinte : 3 publications par jour. Passez à Premium pour publier sans limite.';
  end if;
  return new;
end $$;

drop trigger if exists posts_limit on public.posts;
create trigger posts_limit before insert on public.posts
  for each row execute function public.check_post_limit();

create table if not exists public.app_settings (
  key text primary key,
  value text not null
);
insert into public.app_settings (key, value) values ('prix_fcfa', '1000'), ('numero_paiement', '')
on conflict (key) do nothing;

create table if not exists public.subscription_requests (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null default auth.uid() references auth.users on delete cascade,
  user_name text,
  operateur text not null,
  reference text not null,
  montant integer,
  status text not null default 'en_attente',
  created_at timestamptz not null default now()
);

create or replace function public.set_request_name() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  new.user_name := coalesce(
    (select coalesce(nullif(full_name, ''), email) from public.profiles where id = auth.uid()), 'Membre');
  new.status := 'en_attente';
  return new;
end $$;

drop trigger if exists requests_name on public.subscription_requests;
create trigger requests_name before insert on public.subscription_requests
  for each row execute function public.set_request_name();

alter table public.app_settings enable row level security;
alter table public.subscription_requests enable row level security;

drop policy if exists "lire reglages" on public.app_settings;
drop policy if exists "admin ajoute reglages" on public.app_settings;
drop policy if exists "admin modifie reglages" on public.app_settings;
create policy "lire reglages" on public.app_settings for select to authenticated using (public.is_member());
create policy "admin ajoute reglages" on public.app_settings for insert to authenticated with check (public.is_admin());
create policy "admin modifie reglages" on public.app_settings for update to authenticated using (public.is_admin());

drop policy if exists "voir demandes" on public.subscription_requests;
drop policy if exists "creer demande" on public.subscription_requests;
create policy "voir demandes" on public.subscription_requests for select to authenticated
  using (user_id = auth.uid() or public.is_admin());
create policy "creer demande" on public.subscription_requests for insert to authenticated
  with check (public.is_member() and user_id = auth.uid());

create or replace function public.approve_subscription(req uuid, days integer default 30) returns void
language plpgsql security definer set search_path = public as $$
declare uid uuid;
begin
  if not public.is_admin() then raise exception 'Réservé à l''administrateur'; end if;
  select user_id into uid from public.subscription_requests where id = req and status = 'en_attente';
  if uid is null then raise exception 'Demande introuvable ou déjà traitée'; end if;
  update public.subscription_requests set status = 'approuve' where id = req;
  update public.profiles
    set plan = 'premium',
        plan_expires_at = greatest(now(), coalesce(plan_expires_at, now())) + make_interval(days => days)
    where id = uid;
end $$;

create or replace function public.reject_subscription(req uuid) returns void
language plpgsql security definer set search_path = public as $$
begin
  if not public.is_admin() then raise exception 'Réservé à l''administrateur'; end if;
  update public.subscription_requests set status = 'refuse' where id = req and status = 'en_attente';
end $$;

notify pgrst, 'reload schema';
