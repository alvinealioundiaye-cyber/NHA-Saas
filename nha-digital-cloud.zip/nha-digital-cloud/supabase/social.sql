-- Module Social et shorts : à coller dans Supabase > SQL Editor > Run

create function public.is_member() returns boolean
language sql security definer set search_path = public stable as $$
  select exists (select 1 from public.profiles where id = auth.uid() and role <> 'pending')
$$;

create function public.set_author_name() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  new.author_name := coalesce(
    (select coalesce(nullif(full_name, ''), email) from public.profiles where id = auth.uid()),
    'Membre'
  );
  return new;
end $$;

create table public.posts (
  id uuid primary key default gen_random_uuid(),
  author uuid not null default auth.uid() references auth.users on delete cascade,
  author_name text,
  body text,
  media_url text,
  media_type text check (media_type in ('image', 'video')),
  is_short boolean not null default false,
  created_at timestamptz not null default now()
);
create trigger posts_author before insert on public.posts
  for each row execute function public.set_author_name();

create table public.post_likes (
  post_id uuid not null references public.posts on delete cascade,
  user_id uuid not null default auth.uid() references auth.users on delete cascade,
  primary key (post_id, user_id)
);

create table public.post_comments (
  id uuid primary key default gen_random_uuid(),
  post_id uuid not null references public.posts on delete cascade,
  author uuid not null default auth.uid() references auth.users on delete cascade,
  author_name text,
  body text not null,
  created_at timestamptz not null default now()
);
create trigger comments_author before insert on public.post_comments
  for each row execute function public.set_author_name();

alter table public.posts enable row level security;
alter table public.post_likes enable row level security;
alter table public.post_comments enable row level security;

create policy "lire posts" on public.posts for select to authenticated using (public.is_member());
create policy "creer post" on public.posts for insert to authenticated with check (public.is_member() and author = auth.uid());
create policy "supprimer post" on public.posts for delete to authenticated using (author = auth.uid() or public.is_admin());

create policy "lire likes" on public.post_likes for select to authenticated using (public.is_member());
create policy "ajouter like" on public.post_likes for insert to authenticated with check (public.is_member() and user_id = auth.uid());
create policy "retirer like" on public.post_likes for delete to authenticated using (user_id = auth.uid());

create policy "lire commentaires" on public.post_comments for select to authenticated using (public.is_member());
create policy "creer commentaire" on public.post_comments for insert to authenticated with check (public.is_member() and author = auth.uid());
create policy "supprimer commentaire" on public.post_comments for delete to authenticated using (author = auth.uid() or public.is_admin());

-- Stockage des photos et vidéos (50 Mo maximum par fichier)
insert into storage.buckets (id, name, public, file_size_limit)
values ('media', 'media', true, 52428800)
on conflict (id) do nothing;

create policy "envoyer media" on storage.objects for insert to authenticated
  with check (bucket_id = 'media' and public.is_member());
create policy "supprimer ses media" on storage.objects for delete to authenticated
  using (bucket_id = 'media' and owner = auth.uid());
