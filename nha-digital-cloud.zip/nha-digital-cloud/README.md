# Omonia

Réseau social, shorts, messagerie, boutiques, réunions et lives, avec plans gratuit et Premium.
React + Vite + TypeScript, Supabase, GitHub Pages (site) et Capacitor (APK Android).

## Mise en ligne
- [ ] Supabase > SQL Editor : coller `supabase/omonia.sql` puis Run (relançable sans erreur)
- [ ] GitHub > Actions > Deploy NHA Digital Cloud > Run workflow
- [ ] Ouvrir le site, créer un compte (le premier devient administrateur)
- [ ] Réglages : page Abonnement > prix et numéro Orange Money / Moov

## APK Android
- [ ] Créer `.github/workflows/android.yml` (contenu fourni dans la conversation)
- [ ] Actions > APK Omonia > Run workflow
- [ ] Quand la coche est verte : ouvrir l'exécution > Artifacts > Omonia-APK
